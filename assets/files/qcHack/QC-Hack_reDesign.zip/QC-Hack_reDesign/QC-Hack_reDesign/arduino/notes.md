
- https://www.hackster.io/PSoC_Rocks/hacking-qualcomm-quick-charge-qc-2-0-3-0-with-attiny85-b7627d

Datasheets : 
- [CHY100 (QC 2.0)](https://www.mouser.be/datasheet/2/328/chiphy_family_datasheet_269468-3198404.pdf)
- [CHY103 (QC 3.0)](https://www.mouser.be/datasheet/2/328/chy103_family_datasheet-3196211.pdf)

Existing Arduino Library : https://www.arduino.cc/reference/en/libraries/qc3control/
